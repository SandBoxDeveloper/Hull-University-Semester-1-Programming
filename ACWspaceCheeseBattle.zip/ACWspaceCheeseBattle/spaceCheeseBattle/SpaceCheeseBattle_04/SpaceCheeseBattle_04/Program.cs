﻿/*
 * written by Andre Hitchman
 * 2012
 */

//#define indebug
#define diceRollDebug

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceCheeseBattle_04
{
    class Program
    {
        // array of player, maxium players is 4
        static Player[] Players = new Player[4];

        // hold number of players in the game
        static int numberOfPlayers;

        // checks when a player has reached square 64
        static bool gameOver = false;

        // checks when a player has passed square 64
        static bool passedSquareSixtyFour = false;

        // random dice 
        static Random rand = new Random();

        /* for dice testing purposes */
        // an array that holds a sequence of pre-set values
        static int[] diceValues = new int[] {3, 4, 6, 6, 5, 5, 4, 6, 6, 3, 49, 43, 20, 1, 3, 2, 2};
        // an list that holds the sequence of dice values from diceValues from diceValue array
        static List<int> diceValues1 = new List<int>(diceValues);

        // keeps track of position that has been reached in the array
        static int diceValuePos = 0;

        // an array that holds pre-set values for positions of 'cheese's' on the board
        static int[] cheeseSquares = new int [] {8, 15, 19, 23, 30, 45, 55, 59};
        // an list that holds values from cheese Sqaurespositions based on values from cheeseSquares array 
        static List<int> cheeseSquares1 = new List<int>(cheeseSquares);

        // positon of players next turn to move along the board
        static int targetSquare;

        // used a a ref to if a player has been on a square before
        static bool beenBefore = false;

        

        static bool testModeEntered = true;
        static bool thrownASixAlready = false;
        // used for error conditioning for swapping function
        // has the player selected the person to swap with?
        static bool swapSelected;

      

        #region structs

        struct Player
        {
            public string Name;
            public int Position;
        }
        #endregion
        #region methods

        /// <summary>
        /// method to set the game up
        /// all players position are set to 0, of the board
        /// </summary>
        static void ResetGame()
        {
            // how many players are taking part in the game ?
            // bool used to keep track if the input by the user is the correct format
            bool isValid = true;
            do
            {
                isValid = true; // rests the value isValid is true, if the loop is entered is set to true
                Console.WriteLine();
                Console.WriteLine("How many players are taking part?");
                string numberOfPLayersEntered = Console.ReadLine();

                try
                {
                    numberOfPlayers = int.Parse(numberOfPLayersEntered);
                    // condition, max number of player is 4 and min is 2
                    if (numberOfPlayers > 4 || numberOfPlayers < 2)
                    {
                        Console.WriteLine("Maxium number of players is 4, Minimum number is 2.");
                        Console.WriteLine("Please try again");
                        isValid = false;
                    }
                   
                    
                }
                catch (Exception)
                {
                    isValid = false;
                    Console.WriteLine(numberOfPLayersEntered.ToString()+ " is an invlaid input, try again");
                }
            } while (isValid == false);
            
            
            Console.WriteLine("You have choosen to have: " + numberOfPlayers + " numbers of players");

            // entering name of each player in the game
            for (int i = 0; i < numberOfPlayers; i++)
            {
                // keeps track if the input by the user is valid or not
                bool isNameVaild;
                do
                {
                    isNameVaild = true;
                    Console.WriteLine("Enter the name of player " + (i + 1).ToString());
                    Players[i].Name = Console.ReadLine().Trim(); // removes whitepaces 
                    if (Players[i].Name == string.Empty)
                    {
                        isNameVaild = false;
                        Console.WriteLine("Name cannot be blank");
                    }
                } while (isNameVaild == false);

            }

            // after enterting player information
            // pause game state, then
            // allow user to continue with rest of program
            Console.WriteLine("");
            Console.WriteLine("Press enter to continue ...");

            // setting each players position at the start of the game
            for (int i = 0; i < Players.Length; i++)
            {
                Players[i].Position = 0;
            }
        }

        /// <summary>
        /// Dice Throw method to randomly return values
        /// </summary>
        /// <returns> ints between 1 and 6</returns>
        static int DiceThrow()
        {

        #if diceRollDebug
        // usesd to use the .Length property of the diceValues array
        // so that when the method runs out of numbers
        // it will go back to the start of the array and repeat the process

        // now uses the count method for list
        int spots = diceValues1[diceValuePos];
        diceValuePos += 1;

        // if the diceValue is equall to the last value in the list/array then go back to
        // the beginning of the array
        if (diceValuePos == diceValues1.Count - 1) 
        {
            diceValuePos = 0;
        }

        if(diceValues1[diceValuePos] > 6)
        {
            Console.WriteLine("Dice throw over 6");
            Console.WriteLine("Not aloud");
            diceValuePos += 1;
            if (diceValues1[diceValuePos] > 6)
            {
                Console.WriteLine("The computer has rolled a value > 6");
                Console.WriteLine("We will continue the game from the next suitable value");
                diceValuePos += 1;

                if (diceValues1[diceValuePos] > 6)
                {
                    Console.WriteLine("The computer has rolled a value > 6");
                    Console.WriteLine("We will continue the game from the next suitable value");
                    diceValuePos += 1;

                    if (diceValues1[diceValuePos] > 6)
                    {
                        Console.WriteLine("The computer has rolled a value > 6");
                        Console.WriteLine("We will continue the game from the next suitable value");
                        diceValuePos += 1;

                        if (diceValues1[diceValuePos] > 6)
                        {
                            Console.WriteLine("The computer has rolled a value > 6");
                            Console.WriteLine("We will continue the game from the next suitable value");
                            diceValuePos += 1;
                        }
                    }
                }
            }
        }
        return spots;

        #else
                    return rand.Next(1, 7);
        #endif
          
        }

        /// <summary>
        /// Moves a player onto their next square by adding the value of their roll of the dice
        /// </summary>
        /// <param name="playerNo"></param>
        private static void playerTurn(int playerNo)
        {

            // printing players roll of dice value
            int throwValue = DiceThrow();
            Console.WriteLine(Players[playerNo].Name + " You have rolled a " + throwValue);

            targetSquare = Players[playerNo].Position + throwValue;
            Console.WriteLine("Therefore you are on square " + targetSquare.ToString());

            while (RocketInSquare(targetSquare, playerNo) == true)
            {
                targetSquare = targetSquare + 1;
                Console.WriteLine("we have moved you to " + targetSquare.ToString());
            }

            // setting the current player's postion to their new position on the board
            Players[playerNo].Position = targetSquare;

            // informing player of their new position after they have rolled
            Console.WriteLine("Player " + Players[playerNo].Name + " has moved to location " + targetSquare);
            Console.ReadLine();

            // if player has landed on a square pass 64, execute 
            if (CheckIfPassedSquareSixtyFour() == true)
            {
                int previousPosition;
                Console.WriteLine(Players[playerNo].Name + " positon is: " + targetSquare);
                Console.WriteLine();
                previousPosition = targetSquare - throwValue;
                Players[playerNo].Position = previousPosition;
                Console.WriteLine(Players[playerNo].Name + " previous positon was: " + previousPosition);
                Console.WriteLine(Players[playerNo].Name + " you have been moved back to that position");
                Console.WriteLine(Players[playerNo].Position);
                // set that the player has been on a cheeseSqaure before
                beenBefore = true; 
                gameOver = false;

                /* 
                 code that doesn't work, but in theroy should
                 the princlple is if a player's positon was on a cheeseSquare before
                 set set a bool to true (they have been here before)
                 this is done by looking the the player's previos positon on the board
                 then comparing it to the position of cheeseSqaures
                
                 ------------------------------------------------------------------------
                // check if the current player previous positon was on  cheesepowersquare
                // if yes, set that they have already been on a cheese power square
                for (int j = 0; j < cheeseSquares1.Count; j++ )
                {
                    if (previousPosition == cheeseSquares1[j])
                    {
                        // set that the player has already landed on a cheese square
                        Console.WriteLine("You have already landed on a cheese square");
                        Console.WriteLine("You can't use it twice");
                        beenBefore = true;
                        gameOver = false;
                    }
                }
                */
            }
            
            // if the current player hasn't already landed on a cheese square before
            // then call CheesePowerSquare check method
            if(beenBefore == false)
            {
                if(CheesePowerSquare(targetSquare) == true)
                {
                    // if a player has throw a six already
                    // and they land on a cheese square
                    // execute swapping function for them
                    if (thrownASixAlready == true)
                    {
                        Console.WriteLine("You have throw a 6 before and now have landed on a cheese Square");
                        CheeseSquareStringComparison("S", playerNo);
                    }

                    string SorR;
                    do
                    {
                        Console.WriteLine("Do you want to swap or roll again");
                        Console.WriteLine("Type S to Swap or R for Roll again");
                        SorR = Console.ReadLine().ToUpper();

                    } while (SorR.ToUpper() != "R" && SorR.ToUpper() != "S");

                    // compare response
                    // did player select R or S
                    CheeseSquareStringComparison(SorR, playerNo);

                    // conditon to check is user's input is empty
                    if (SorR == string.Empty)
                    {
                        Console.WriteLine("Please type \"S\" or \"R\" ");
                    }

                }
            }

            

            // conditions for
            // rolling sixes
            // and rolling sixes in consestion
            if (throwValue == 6)
            {
                // go to dealySix method
                deadlySix(playerNo, throwValue);  
            }
        }

        /// <summary>
        /// Checks if a player has passed square number 64
        /// if they have method returns true, else returns false
        /// </summary>
        /// <returns>True or False</returns>
        static bool CheckIfPassedSquareSixtyFour()
        {
            for (int i = 0; i < numberOfPlayers; i++)
            {
                // if player has passed square 64 then move them back to their previous position
                if (Players[i].Position > 64)
                {
                    Console.WriteLine("You have passed sqaure 64");
                    // set passed square 64 to true, (yes player has passed square number 64)
                    passedSquareSixtyFour = true;
                    return passedSquareSixtyFour;
                }
            }
            // else continue with the game
            return false;
        }

        /// <summary>
        /// Checks to see if there is a rocket on a particular square
        /// </summary>
        /// <param name="squareNo"></param>
        /// <returns>True, if rocket is in a square</returns>
        static bool RocketInSquare(int squareNo, int currentPlayerID) 
        {
            for (int i = 0; i < Players.Length; i++)
            {
                if (Players[i].Position == squareNo && currentPlayerID != i)
                {
                    Console.WriteLine();
                    Console.WriteLine("There is already an player here");
                    return true;
                }
            }
            Console.WriteLine();
            Console.WriteLine("No player here");
            return false;
        }

        /// <summary>
        /// Displays current position of every player in the game
        /// </summary>
        static void ShowStatus()
        {
            Console.WriteLine("SPACE CHESSES BATTLE STATUS REPORT");
            Console.WriteLine("==================================");
            Console.WriteLine("");
            Console.WriteLine("There are " + numberOfPlayers + " players in the game ");
            for (int i = 0; i < numberOfPlayers; i++)
            {
                Console.WriteLine(Players[i].Name+ " is on " +Players[i].Position.ToString());
            }
        }

        /// <summary>
        /// Executes each move of every player within the game
        /// </summary>
        static void MakeMoves()
        {
            int i;
            for (i = 0; i < numberOfPlayers && !gameOver; i++)
            {
                
                playerTurn(i); 
                ExactlySixtyFour();
                CheckIfPassedSquareSixtyFour();
                

                // if player lands on square 64, execute
                if (ExactlySixtyFour() == true)
                {
                    // set game over to true
                    // then display game over screen
                    gameOver = true;
                    GameOver();
                }   
            }
        }
        
        /// <summary>
        /// method that checks through the
        /// cheese square positions
        /// </summary>
        /// <param name="squareNo"></param>
        /// <returns>returns true if the square has cheese power, else false</returns>
        static bool CheesePowerSquare(int squareNo)
        {
            // loop through players
            for (int i = 0; i < Players.Length; i++)
            {
                // loop through cheeseSquare positions
                for (int j = 0; j < cheeseSquares1.Count; j++)
                {
                    if (Players[i].Position == cheeseSquares1[j])
                    {
                        Console.WriteLine(Players[i].Name + " You have landed on a cheese");
                        return true;   
                    }
                }
            }
            return false;
        }
    
        /// <summary>
        /// method to swap position of two players
        /// </summary>
        /// <param name="p1">player number 1</param>
        /// <param name="p2">player number 2</param>
        static void SwapPlayerPosition(int p1, int p2)
        {
            // need to update targetSquare

            // hold positions of two players selected
            int tempPlayerPosition1 = Players[p1].Position;
            int tempPlayerPosition2 = Players[p2].Position;

            for (int i = 0; i < numberOfPlayers; i++)
            {
                // swap positions of players
                Players[p1].Position = tempPlayerPosition2;
                Players[p2].Position = tempPlayerPosition1;
            }

            Console.WriteLine();
            Console.WriteLine("====================== CHEESE POWER: SWAPPING ======================"); // 24, ==
            Console.WriteLine("Player " +Players[p1].Name+ " new position is: " + Players[p1].Position);
            Console.WriteLine("Player " +Players[p2].Name+ " new position is: " + Players[p2].Position);
            Console.WriteLine("====================== ====================== ======================");
            Console.WriteLine();  
        }

        /// <summary>
        /// Method to compare what player the user has selected to swap with
        /// </summary>
        /// <param name="response">user response</param>
        /// <param name="currentPlayerNo">player in user number</param>
        static void SwapNameStringComparison(string response, int currentPlayerNo)
        {
            
            response = response.ToLower();
            // hard coded string literals used for string comparisons for each player name
            string sawpName1 = Players[0].Name;
            string sawpName2 = Players[1].Name;
            string sawpName3 = Players[2].Name;
            string sawpName4 = Players[3].Name;

            // state1 is player1
            // state2 is player2
            // state3 is player3
            // state4 is player4

            // check if the input from the user is equal to "player 1's name"
            bool state1 = response.Equals(sawpName1, System.StringComparison.Ordinal);
            // check if the input from the user is equal to "player 2's name"
            bool state2 = response.Equals(sawpName2, System.StringComparison.Ordinal);
            // check if the input from the user is equal to "player 3's name"
            bool state3 = response.Equals(sawpName3, System.StringComparison.Ordinal);
            // check if the input from the user is equal to "player 4's name"
            bool state4 = response.Equals(sawpName4, System.StringComparison.Ordinal);

            // when reponse from user is equall to one of the players in the game name
            // swap with the player they selected
            if (state1 || state2 | state3 || state4 == true)
            {
                if (state1 == true)
                {
                    swapSelected = true;
                    Console.WriteLine("You have selected" + Players[0].Name);
                    // swap players
                    SwapPlayerPosition(currentPlayerNo, 0);
                    // inform player of who they have swaped with
                    Console.WriteLine("Players " + Players[currentPlayerNo].Name + " and " + Players[0].Name + " have now swaped");
                }

                if (state2 == true)
                {
                    swapSelected = true;
                    Console.WriteLine("You have selected " + Players[1].Name.ToUpper());
                    // swap players
                    SwapPlayerPosition(currentPlayerNo, 1);
                    // inform player of who they have swaped with
                    Console.WriteLine("Players " + Players[currentPlayerNo].Name + " and " + Players[1].Name + " have now swaped");
                }

                if (state3 == true)
                {
                    swapSelected = true;
                    Console.WriteLine("You have selected" + Players[2].Name);
                    SwapPlayerPosition(currentPlayerNo, 2);
                    Console.WriteLine("Players " + Players[currentPlayerNo].Name + " and " + Players[2].Name + " have now swaped");
                }

                if (state4 == true)
                {
                    swapSelected = true;
                    Console.WriteLine("You have selected" + Players[3].Name);
                    SwapPlayerPosition(currentPlayerNo, 3);
                    Console.WriteLine("Players " + Players[currentPlayerNo].Name + " and " + Players[3].Name + " have now swaped");
                }
            }

            if (state1 || state2 || state3 || state4 == false)
            {
                swapSelected = true;
                Console.WriteLine("Please choose a player to swap with");
                Console.WriteLine();
                Console.WriteLine("Player " + Players[currentPlayerNo].Name.ToUpper());
                Console.WriteLine("Who do you wish to swap with?");
                Console.WriteLine();
                Console.WriteLine("----------Current Game Information----------");
                for (int i = 0; i < numberOfPlayers; i++)
                {
                    Console.WriteLine();
                    Console.WriteLine(Players[i].Name + " is at square number " + Players[i].Position);
                }
                Console.WriteLine("--------------------------------------------");
                Console.WriteLine();

                string playerSelected = Console.ReadLine();
                Console.WriteLine();
                SwapNameStringComparison(playerSelected, currentPlayerNo);
                Console.WriteLine("Press Enter to continue");
                Console.ReadLine();
            }
            
        }

        /// <summary>
        /// Compares two strings agasint each other
        /// are the strings compared S or R
        /// </summary>
        /// <param name="response"></param>
        static void CheeseSquareStringComparison(string response, int playerNo)
        {
            // hard coded string literals used for string comparisons
            string sawpResponse = "S";
            string RollAgainResponse = "R";

            // state1 is Swapping
            // state2 is Roll Again

            // check if the input from user is equal to "S"
            bool state1 = response.Equals(sawpResponse, System.StringComparison.Ordinal);
            // check if the input from the user is equal to "R"
            bool state2 = response.Equals(RollAgainResponse, System.StringComparison.Ordinal);

            // when reponse from user is Either "R" or "S"
            // execute swapping or rolling-again function
            if (state1 || state2 == true)
            {
                Console.WriteLine();
                Console.WriteLine("Match Found");
                if (state1 == true)
                {
                    // execute swapping function
                    Console.WriteLine();
                    Console.WriteLine("Swapping Function Active");
                    Console.WriteLine("Player " + Players[playerNo].Name.ToUpper());
                    Console.WriteLine("Who do you wish to swap with?");
                    Console.WriteLine();
                    Console.WriteLine("----------Current Game Information----------");
                    for (int i = 0; i < numberOfPlayers; i++)
                    {
                        Console.WriteLine();
                        Console.WriteLine(Players[i].Name + " is at square number " + Players[i].Position);
                    }
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine();

                    string playerSelected = Console.ReadLine();
                    //int numberOfPlayerSelected = int.Parse(playerSelected);

                    // Display to screen what player has been selected to be swaped
                    Console.WriteLine();
                    SwapNameStringComparison(playerSelected, playerNo);
                    
                    //Console.WriteLine("You have selected player " + Players[numberOfPlayerSelected - 1].Name);
                    //Console.WriteLine();

                    // Sawp current player with the player that has been selected
                    //SwapPlayerPosition(playerNo, numberOfPlayerSelected - 1);
                    // Displaying informative information to the users
                    //Console.WriteLine("Players " + Players[playerNo].Name + " and " + Players[numberOfPlayerSelected - 1].Name + " have now swaped");
                    Console.WriteLine("Press Enter to continue");
                    Console.ReadLine();
                }

                if (state1 == true && swapSelected == false)
                {
                    // execute swapping function
                    Console.WriteLine();
                    Console.WriteLine("Swapping Function Active");
                    Console.WriteLine("Player " + Players[playerNo].Name.ToUpper());
                    Console.WriteLine("Who do you wish to swap with?");
                    Console.WriteLine();
                    Console.WriteLine("----------Current Game Information----------");
                    for (int i = 0; i < numberOfPlayers; i++)
                    {
                        Console.WriteLine();
                        Console.WriteLine(Players[i].Name + " is at square number " + Players[i].Position);
                    }
                    Console.WriteLine("--------------------------------------------");
                    Console.WriteLine();

                    string playerSelected = Console.ReadLine();
                    //int numberOfPlayerSelected = int.Parse(playerSelected);

                    // Display to screen what player has been selected to be swaped
                    Console.WriteLine();
                    SwapNameStringComparison(playerSelected, playerNo);

                    //Console.WriteLine("You have selected player " + Players[numberOfPlayerSelected - 1].Name);
                    //Console.WriteLine();

                    // Sawp current player with the player that has been selected
                    //SwapPlayerPosition(playerNo, numberOfPlayerSelected - 1);
                    // Displaying informative information to the users
                    //Console.WriteLine("Players " + Players[playerNo].Name + " and " + Players[numberOfPlayerSelected - 1].Name + " have now swaped");
                    Console.WriteLine("Press Enter to continue");
                    Console.ReadLine();
                }
            }
            

            if (state2 == true)
            {
                // execute roll again
                Console.WriteLine("Rolling Again Active");
                Console.WriteLine(Players[playerNo].Name + " Press enter to roll again");
                Console.ReadLine();
                playerTurn(playerNo);
            }
            

            // if when comparing against string "S"
            if (state1 == false)
            {
                Console.WriteLine("Ordinal comparison: {0} and {1} are {2}", response, sawpResponse, state1 ? "equal." : "not equal.");
                // then check is response !== state2
                // if response is not equal to "S" and not "R"
                if (state2 == false)
                {
                    Console.WriteLine("Ordinal comparison: {0} and {1} are {2}", response, RollAgainResponse, state1 ? "equal." : "not equal.");
                    Console.WriteLine("{0} doesn't match with {1} or {2}", response, RollAgainResponse, sawpResponse);
                }
            }

            // if when comparing against string "R"
            if (state2 == false)
            {
                Console.WriteLine("Ordinal comparison: {0} and {1} are {2}", response, RollAgainResponse, state2 ? "equal." : "not equal.");
                // then check is response !== state1
                // if response is not equal to "R" or "S"
                if (state1 == false)
                {
                    // then check is response !== state2
                    Console.WriteLine("Ordinal comparison: {0} and {1} are {2}", response, sawpResponse, state1 ? "equal." : "not equal.");
                    Console.WriteLine("{0} doesn't match with {1} or {2}", response, sawpResponse, RollAgainResponse);
                }
            }

        }

        /// <summary>
        /// function for rolling 6's
        /// </summary>
        /// <param name="playerNo">player who rolled a 6</param>
        /// <param name="throwValue">dice value they threw</param>
        static void deadlySix(int playerNo, int throwValue)
        {
            thrownASixAlready = true;
            Console.WriteLine(Players[playerNo].Name + " You have rolled a 6"); // rolled 6, want to roll again?
            Console.WriteLine("Type \"Y\" for yes to roll again or Type \"N\" for no to continue with the game");
            Console.WriteLine("six 1");
            string deadlySixResponse = Console.ReadLine().ToUpper();

           

            switch (deadlySixResponse)
            {
                case "Y":
                    thrownASixAlready = true;
                    playerTurn(playerNo);
                    break;

                case "N":
                    // if no, then move on to next player
                        
                    break;
            }

            if (throwValue == 6)
            {
                Console.WriteLine(Players[playerNo].Name + " You have rolled a 6"); // rolled 6, want to roll again?
                Console.WriteLine("Type \"Y\" for yes or Type \"N\" for no");
                Console.WriteLine("six 2");
                string deadlySixResponse2 = Console.ReadLine();

                switch (deadlySixResponse2)
                {
                    case "Y":
                        thrownASixAlready = true;
                        playerTurn(playerNo);
                        break;

                    case "N":
                        // move on to next player
                        break;

                }

                if (throwValue == 6)
                {
                    thrownASixAlready = true;
                    Console.WriteLine(Players[playerNo].Name + " You have rolled a third 6 in a row");// rolled a 3rd six
                    Console.WriteLine("You will be sent back to the start as a result");// you will be sent back to start
                    Console.WriteLine("six 3");
                    Players[playerNo].Position = 0;
                }
            }

                
            
        }
        /// <summary>
        /// Checks whether if a player has rolled 6(s)
        /// if true, they are to roll again.
        /// </summary>
        static void CheckDeadlySix(int playerNo)
        {
            if (DiceThrow() == 6)
            {
                Console.WriteLine("Would you like to roll again...");
                string YesOrNo = Console.ReadLine();

                try
                {

                    if (YesOrNo == "Y")
                    {
                        // Roll dice again for player
                        // then move them to new position
                        Console.WriteLine("You choose Yes");
                        thrownASixAlready = true;
                        playerTurn(playerNo);
                    }

                    if (YesOrNo == "N")
                    {
                        // contine with playerTurn
                        Console.WriteLine("You choose No");
                    }
                    
                }

                catch (Exception)
                {
                    Console.WriteLine("Please choose if you would like to roll again");
                }
  
            }
           
        }

        /// <summary>
        /// Displays Game Over screen
        /// information displayed shows option to restart the game
        /// or end the game
        /// </summary>
        static void GameOver()
        {
            if(gameOver == true)
            {
                Console.WriteLine("====== Game Over ======");
                Console.WriteLine();
                Console.WriteLine("Do you wish to play again");
                Console.WriteLine("Type \"Y\" for Yes or \"N\" for No");
                string YesOrNoResponse = Console.ReadLine().ToUpper();

                try
                {
                    if (YesOrNoResponse == "Y")
                    {
                        Console.WriteLine();
                        Console.WriteLine("Restating Game......");
                        Console.WriteLine();
                        ResetGame();
                        gameOver = false;
                    }

                    if (YesOrNoResponse == "N")
                    {
                        //Quite Application
                        Console.WriteLine("Press Enter to Quit Game");
                        gameOver = true;
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Type Y or N");
                }
            }
        }

        /// <summary>
        /// Checks if a player has landed on square 64
        /// </summary>
        /// <returns>True, if player has landed on square 64</returns>
        static bool ExactlySixtyFour()
        {
            for (int i = 0; i < numberOfPlayers; i++)
            {
                if (Players[i].Position == 64)
                {
                    Console.WriteLine("You have won");
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Runs testing mode, to allow the user to make changes to game play object/states
        /// </summary>
        static void RunTestMode()
        {
            // code to allow user to select location of cheese square locations
            cheeseSquares1.Clear();// clear current list
            int cheeseNo; 
            Console.WriteLine("Please select where you would like cheeses to be placed on the board");
            Console.WriteLine("{cheeseLocation1, cheeseLocation2, ... , cheeseLocation8}");
            Console.WriteLine();

           
            // allow only 8 values to be inputed
            for (int i = 1; i < 9; i++)
            {
                Console.WriteLine("Input Cheese number {0}", (i));
                cheeseNo = int.Parse(Console.ReadLine());
                // add value to list of cheeseSquares positions
                cheeseSquares1.Add(cheeseNo);
            }

            foreach (var item in cheeseSquares1)
            {
                Console.Write("{0}", item.ToString()+ " ");
            }
            Console.ReadLine();



            // code to allow the user the select sequence of diceThrow values
            diceValues1.Clear();// clear current list
            int diceNo;
            Console.WriteLine();
            Console.WriteLine("Please select the sequence in which you would like the die values to be");
            Console.WriteLine("{diceThrowValue1, diceThrowValue2, ... , diceThrowValue7}");
            Console.WriteLine();
            // allow only 7 values to be inputed
            for (int i = 0; i < 8; i++)
            {
                Console.WriteLine("Input die {0}", (i) + " value");
                diceNo = int.Parse(Console.ReadLine());
                // add value to list of cheeseSquares positions
                diceValues1.Add(diceNo);
            }

            foreach(var item in diceValues1)
            {
                Console.Write("{0}", item.ToString()+ " ");
            }
            Console.ReadLine();
            Console.WriteLine();

           
        }

        /// <summary>
        /// Runs normal game state mode
        /// </summary>
        static void RunGame()
        {
            // clearing the player positions array
            ResetGame();
            Console.ReadLine();

           
            while (!gameOver)
            {
                MakeMoves();
                ShowStatus();
                

                if (gameOver)
                {
                    break;
                }
                Console.ReadLine();
            }
        }

        /// <summary>
        /// Used to compare which mode the user has selected
        /// testMode or GameMode
        /// </summary>
        /// <param name="response">compare string</param>
        static void GameSelectModeComparison(string response)
        {
            // hard coded string literals used for string comparisons
            string testSelected = "<test>";
            string gameSelected = "<game>";

            // state1 is test mode
            // state2 is game mode

            // check if the input from user is equal to "<test>"
            bool state1 = response.Equals(testSelected, System.StringComparison.Ordinal);
            // check if the input from the user is equal to "<game>"
            bool state2 = response.Equals(gameSelected, System.StringComparison.Ordinal);

            // when reponse from user is Either "<test>" or "<game>"
            // execute test or game mode
            if (state1 || state2 == true)
            {
                Console.WriteLine();
                Console.WriteLine("Match Found");
                if (state1 == true)
                {
                    // execute testMode
                    Console.WriteLine();
                    Console.WriteLine("TestMode Active");
                    Console.WriteLine();
                    WhichModeToExecute(response);   
                }

                if (state2 == true)
                {
                    // execute gameMode
                    Console.WriteLine();
                    Console.WriteLine("GameMode Active");
                    Console.WriteLine();
                    WhichModeToExecute(response);      
                }
            }

            // if when comparing against string "<test>"
            if (state1 == false)
            {
                // print string comparison message, for testing purposes
                //Console.WriteLine("Ordinal comparison: {0} and {1} are {2}", response, testSelected, state1 ? "equal." : "not equal.");
                // then check if response !== state2
                // if response is not equal to "<test>" and not "<game>"
                if (state2 == false)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Please select correct mode");
                    Console.WriteLine("");
                    //Console.WriteLine("{0} doesn't match with {1} or {2}", response, gameSelected, testSelected);
                }
            }
        }

        /// <summary>
        /// Executes which mode of the game to execute, GamePlayingMode or TestMode
        /// based on what the users inputs from to avaliable options
        /// </summary>
        /// <param name="response">Which mode to execute</param>
        static void WhichModeToExecute(string response)
        {
            if (response == string.Empty)
            {
                Console.WriteLine("You didn't select an Mode...");
                Console.WriteLine("Please try again");
                Console.WriteLine();
            }

            if (response == "<test>")
            {
                RunTestMode();
            }
            if (response == "<game>")
            {
                RunGame();
            }
        }

        /// <summary>
        /// Used to read the reponse from the user from the main method 
        /// on
        /// which mode of the program they wish to execute
        /// </summary>
        static void ReadLineMethodForStartOfGame()
        {
            Console.WriteLine("Type <test> for TestMode");
            Console.WriteLine("Type <game> for GameMode");
            string modeResponse = Console.ReadLine().ToLower();

            testModeEntered = true;

            try
            {
                if (modeResponse != string.Empty)
                {
                    testModeEntered = true;
                    // compare reponse
                    GameSelectModeComparison(modeResponse);
                }

                if (modeResponse == string.Empty)
                {
                    testModeEntered = false;
                    Console.WriteLine("You didn't select an Mode...");
                    Console.WriteLine("Please enter a mode");
                    Console.WriteLine();
                }
            }

            catch (Exception)
            {
                testModeEntered = false;
                Console.WriteLine("input invalid");
                Console.ReadLine();
            }   
        }

        #endregion

        #region main

        static void Main(string[] args)
        {
            Console.WriteLine("What Mode would you like to run?");
            Console.WriteLine("TestMode? or GameMode?");
            ReadLineMethodForStartOfGame();

            do
            {
                Console.WriteLine("What Mode would you like to run?");
                Console.WriteLine("TestMode? or GameMode?");
                ReadLineMethodForStartOfGame();
            } while (testModeEntered == false);

        }

        #endregion

        // need to work on deadly six

    }
}